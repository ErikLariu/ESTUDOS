numero = 0

while numero <= 100:
    print(numero)
    numero += 1