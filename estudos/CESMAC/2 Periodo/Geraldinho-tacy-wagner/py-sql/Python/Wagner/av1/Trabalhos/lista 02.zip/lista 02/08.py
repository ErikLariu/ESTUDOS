numero = int(input("Digite o numero: "))

if numero % 2 == 1:
    print("numero primo")
elif numero == 2:
    print("numero primo")
else:
    print("numero nao primo")