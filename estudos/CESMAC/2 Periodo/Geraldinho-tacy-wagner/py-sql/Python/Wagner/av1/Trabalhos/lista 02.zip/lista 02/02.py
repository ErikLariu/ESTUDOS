numero = 0
numero_final = int(input("Digite o numero maximo: "))

while numero <= numero_final:
    print(numero)
    numero += 1