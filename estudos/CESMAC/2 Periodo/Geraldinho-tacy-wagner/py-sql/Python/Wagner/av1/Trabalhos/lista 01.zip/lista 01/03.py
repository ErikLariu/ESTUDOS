letra = str(input("Digite a letra: ")).lower()

if letra in ['a', 'e', 'i', 'o', 'u']:
    print("vogal")
else: 
    print("consoante")