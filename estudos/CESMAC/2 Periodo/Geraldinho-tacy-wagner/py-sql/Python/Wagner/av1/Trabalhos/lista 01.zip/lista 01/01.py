numero = int(input("Digite o numero:"))

if (numero % 2 == 1): 
    print("impar")
else:
    print("Par")