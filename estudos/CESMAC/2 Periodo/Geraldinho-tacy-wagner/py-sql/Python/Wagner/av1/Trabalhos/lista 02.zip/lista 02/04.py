a= 0
b = 1
while a <= 500:
    print(a)
    a, b = b, a + b