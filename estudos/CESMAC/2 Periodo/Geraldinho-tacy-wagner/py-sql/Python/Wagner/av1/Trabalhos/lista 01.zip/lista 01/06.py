turno = str(input("Digite seu turno: ")).lower()

if (turno == 'm'): 
    print("bom dia!")
elif (turno == 'v'):
    print("boa tarde!")
elif (turno == 'n'):
    print("boa noite!")
else:
    print("invalido")