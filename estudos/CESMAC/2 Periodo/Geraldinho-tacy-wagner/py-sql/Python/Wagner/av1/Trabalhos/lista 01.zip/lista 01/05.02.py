numero1 = float(input("Digite o primeiro numero: "))
numero2 = float(input("Digite o primeiro numero: "))
numero3 = float(input("Digite o primeiro numero: "))

maior = max (numero1, numero2, numero3)

print("Maior numero: ", maior)