CREATE TABLE usuarios (
usuario_id SERIAL PRIMARY KEY,
nome VARCHAR(100) NOT NULL,
nome_usuario VARCHAR(50) NOT NULL,
pais VARCHAR(50) NOT NULL
);

CREATE TABLE plataformas (
plataforma_id SERIAL PRIMARY KEY,
nome VARCHAR(50) NOT NULL
);

CREATE TABLE postagens (
postagem_id SERIAL PRIMARY KEY,
usuario_id INT REFERENCES usuarios(usuario_id),
plataforma_id INT REFERENCES plataformas(plataforma_id),
data_postagem DATE,
tipo VARCHAR(20),
descricao TEXT
);

CREATE TABLE hashtags (
hashtag_id SERIAL PRIMARY KEY,
texto VARCHAR(100) NOT NULL
);

CREATE TABLE postagens_hashtags (
postagem_id INT REFERENCES postagens(postagem_id),
hashtag_id INT REFERENCES hashtags(hashtag_id),
PRIMARY KEY (postagem_id, hashtag_id)
);

CREATE TABLE engajamentos (
usuario_id INT NOT NULL,
postagem_id INT NOT NULL,
plataforma_id INT NOT NULL
);

INSERT INTO usuarios (usuario_id, nome, nome_usuario, pais) VALUES
(4714762, 'JEFIM BALA SILVA', 'jefim_bala', 'Brasil'),
(4714763, 'JANDIRA SOUZA SILVA', 'jandira_silva', 'Brasil'),
(4714764, 'AMAURI LIMA', 'amauri_lima', 'Brasil'),
(4714765, 'FIDEL MOREIRA', 'el_comandante', 'Brasil'),
(4714766, 'FERNANDO AMORIM', 'fernandin_amorin', 'Brasil');

INSERT INTO plataformas (plataforma_id, nome) VALUES
(1, 'instagram'),
(2, 'twitter'),
(3, 'facebook');

INSERT INTO postagens (postagem_id, usuario_id, plataforma_id, data_postagem, tipo, descricao) VALUES
(766311, 4714762, 1, '2025-03-01', 'stories', 'foto do mar'),
(766312, 4714763, 2, '2025-04-07', 'texto', 'comentário sobre um familiar'),
(766313, 4714764, 3, '2025-04-09', 'texto com foto', 'comentário sobre um filme');

INSERT INTO hashtags (hashtag_id, texto) VALUES
(11, '#filtrotiktok'),
(22, '#redpill'),
(33, '#lgbtqplus'),
(44, '#estagio'),
(55, '#formula1');